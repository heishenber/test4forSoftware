package com.wpy.t4_2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class T42ApplicationTests {

    @Test
    void contextLoads() {
    }

}
