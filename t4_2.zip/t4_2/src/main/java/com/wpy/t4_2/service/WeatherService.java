package com.wpy.t4_2.service;

import org.springframework.stereotype.Service;

@Service
public class WeatherService {
    public String getWeather(String city) {

        String url = "http://www.webxml.com.cn/WebServices/WeatherWebService.asmx/getWeatherbyCityName?theCityName=" + city;


    }
}
