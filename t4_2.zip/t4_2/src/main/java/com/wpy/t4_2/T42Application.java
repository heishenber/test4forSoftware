package com.wpy.t4_2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class T42Application {

    public static void main(String[] args) {
        SpringApplication.run(T42Application.class, args);
    }

}
