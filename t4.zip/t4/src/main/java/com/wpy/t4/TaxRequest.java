package com.wpy.t4;

public class TaxRequest {
    private double income;



    // Getters and Setters


    public double getIncome() {
        return income;
    }

    public void setIncome(double income) {
        this.income = income;
    }
}

