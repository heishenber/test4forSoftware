package com.wpy.t4;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class TaxController {
    private final TaxService taxService;

    public TaxController(TaxService taxService) {
        this.taxService = taxService;
    }

    @PostMapping("/calculateTax")
    public TaxResponse calculateTax(@RequestBody TaxRequest request) {
        return taxService.calculateTax(request.getIncome());
    }
}
