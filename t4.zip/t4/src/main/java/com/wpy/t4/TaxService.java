package com.wpy.t4;

import org.springframework.stereotype.Service;

@Service
public class TaxService {
    public TaxResponse calculateTax(double income) {
        double tax = income * 0.2; // 假设20%的税率
        double netIncome = income - tax;

        TaxResponse response = new TaxResponse();
        response.setTax(tax);
        response.setNetIncome(netIncome);
        return response;
    }
}
