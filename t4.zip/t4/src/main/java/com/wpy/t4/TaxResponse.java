package com.wpy.t4;

public class TaxResponse {
    private double tax;
    private double netIncome;

    // Getters and Setters

    public double getTax() {
        return tax;
    }

    public void setTax(double tax) {
        this.tax = tax;
    }

    public double getNetIncome() {
        return netIncome;
    }

    public void setNetIncome(double netIncome) {
        this.netIncome = netIncome;
    }
}
